self.addEventListener('push',event=>{
  let message={};
  try { message=event.data?.json() || {}; } catch {}
  event.waitUntil(self.registration.showNotification(message.title || 'ETCH CRM',{
    body:message.body || 'Follow-up reminder',icon:'/etch-icon.png',tag:message.tag || 'etch-reminder',data:{url:'/?view=followups'}
  }));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  event.waitUntil(clients.openWindow(event.notification.data?.url || '/?view=followups'));
});

