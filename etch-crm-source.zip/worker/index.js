const headers = {'cache-control':'private, no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer'};
const maximumBytes = 1500000;
function json(value,status=200) {
  return Response.json(value,{status,headers});
}
function allowedWrite(request, env) {
  const email=request.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
  return Boolean(email && env.ETCH_OWNER_EMAIL && email===env.ETCH_OWNER_EMAIL.trim().toLowerCase());
}
function allowLiveViewer(request,env) {
  const email=request.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
  return Boolean(email && (env.ETCH_LIVE_VIEWER_EMAILS || '').split(',').some(value=>value.trim().toLowerCase()===email));
}
function demoPage() {
  const date=new Date().toISOString().slice(0,10);
  const future=(days)=>new Date(Date.parse(date)+days*86400000).toISOString().slice(0,10);
  const company=(id,name,industry)=>({id,name,industry,notes:'Fictional company for illustration.'});
  const deals=[
    {id:'d1',name:'Manufacturing ERP rollout',company:'c1',stage:0,amount:'120000',probability:'25',next:'Schedule a discovery call',due:future(7),source:'ترشيح',requestedSapProduct:'SAP S/4HANA Cloud Public Edition'},
    {id:'d2',name:'Finance module expansion',company:'c2',stage:2,amount:'75000',probability:'55',next:'Review the workshop agenda',due:future(2),forecast:'Best case',priority:'عالية',requestedModule:'SAP FI'},
    {id:'d3',name:'People operations modernization',company:'c3',stage:3,amount:'94000',probability:'80',next:'Review the proposal',due:date,forecast:'Commit',requestedSapProduct:'SAP SuccessFactors'},
    {id:'d4',name:'ERP support renewal',company:'c1',stage:4,amount:'35000',probability:'100',actualAmount:'35000',actualClose:date,next:'',due:'',requestType:'دعم وصيانة'}
  ].map(deal=>({contact:'',owner:'Demo Sales Team',currency:'USD',close:date,notes:'Illustrative deal only.',history:[],createdOn:date,stageOn:date,...deal}));
  const records={companies:[
    company('c1','Demo Manufacturing','التصنيع'),
    company('c2','Demo Retail','التجزئة'),
    company('c3','Demo Services','الخدمات المهنية')
  ],contacts:[],deals,targets:{[date.slice(0,7)]:150000}};
  const payload=JSON.stringify({date,contactsVisible:false,records}).replace(/</g,'\u003c');
  return appHtml.replace('<html lang="ar" dir="rtl">','<html lang="ar" dir="rtl" data-snapshot data-demo="true">')
    .replace('id="etch-snapshot"></script>',()=> 'id="etch-snapshot">'+payload+'</script>');
}

function validRecords(records) {
  return records && typeof records==='object' && ['companies','contacts','deals'].every(key=>Array.isArray(records[key]));
}
async function readBody(request) {
  const reader=request.body?.getReader();
  if (!reader) return null;
  let bytes=0;
  let result='';
  const decoder=new TextDecoder();
  while (true) {
    const {done,value}=await reader.read();
    if (done) break;
    bytes+=value.byteLength;
    if (bytes>maximumBytes) { await reader.cancel(); throw new RangeError('size'); }
    result+=decoder.decode(value,{stream:true});
  }
  return JSON.parse(result+decoder.decode());
}
async function shared(request,env,owner,url) {
  if (request.method==='GET') {
    const read=()=>env.DB.prepare('SELECT s.revision, s.records, s.updated_at, COALESCE(p.contacts_visible, 0) AS contacts_visible FROM (SELECT 1 AS id) q LEFT JOIN shared_crm s ON s.id=q.id LEFT JOIN shared_crm_privacy p ON p.id=q.id').first();
    let row=await read();
    const viewer=!owner || url.searchParams.get('viewer')==='1';
    let original=row.records?JSON.parse(row.records):null;
    let records=original?migrateLeadOwners(original):null;
    if (!viewer && records!==original) {
      const stamp=new Date().toISOString();
      const updated=await env.DB.prepare('UPDATE shared_crm SET revision=revision+1, records=?, updated_at=? WHERE id=1 AND revision=? RETURNING revision')
        .bind(JSON.stringify(records),stamp,row.revision).first();
      if (updated) row={...row,revision:updated.revision,updated_at:stamp};
      else {
        row=await read();
        original=row.records?JSON.parse(row.records):null;
        records=original?migrateLeadOwners(original):null;
      }
    }
    const contactsVisible=Boolean(row.contacts_visible);
    if (viewer && records) records={...records,deals:records.deals.map(({remindAt,...deal})=>deal)};
    return json({revision:row.revision || 0,records:viewer&&!contactsVisible&&records?projectManagerRecords(records):records,updatedAt:row.updated_at,contactsVisible});
  }
  if (!['PUT','PATCH'].includes(request.method)) return json({error:'method'},405);
  if (!owner) return json({error:'read_only'},403);
  const origin=request.headers.get('origin');
  if ((!origin || (origin!==env.ETCH_PUBLIC_ORIGIN && origin!==url.origin))) return json({error:'origin'},403);
  if (!request.headers.get('content-type')?.startsWith('application/json')) return json({error:'type'},415);
  let payload;
  try { payload=await readBody(request); } catch (error) { return json({error:error instanceof RangeError?'too_large':'invalid'},error instanceof RangeError?413:400); }
  if (request.method==='PATCH') {
    if (typeof payload?.contactsVisible!=='boolean') return json({error:'invalid'},400);
    await env.DB.prepare('INSERT INTO shared_crm_privacy (id, contacts_visible) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET contacts_visible=excluded.contacts_visible')
      .bind(payload.contactsVisible?1:0).run();
    return json({contactsVisible:payload.contactsVisible});
  }
  if (!payload || !Number.isSafeInteger(payload.revision) || payload.revision<0 || !validRecords(payload.records)) return json({error:'invalid'},400);
  const records=JSON.stringify(migrateLeadOwners(payload.records));
  const stamp=new Date().toISOString();
  const row=payload.revision===0
    ? await env.DB.prepare('INSERT INTO shared_crm (id, revision, records, updated_at) VALUES (1, 1, ?, ?) ON CONFLICT(id) DO NOTHING RETURNING revision').bind(records,stamp).first()
    : await env.DB.prepare('UPDATE shared_crm SET revision=revision+1, records=?, updated_at=? WHERE id=1 AND revision=? RETURNING revision').bind(records,stamp,payload.revision).first();
  return row ? json({revision:row.revision,updatedAt:stamp}) : json({error:'conflict'},409);
}
export default {
  async fetch(request,env) {
    const url=new URL(request.url);

    if (url.pathname==='/api/push/dispatch') return dispatchMobilePush(request,env);
    if (request.method==='GET' || request.method==='HEAD') {
      if (url.pathname==='/etch-push.js') return new Response(request.method==='HEAD'?null:pushService,{headers:{...headers,'content-type':'application/javascript'}});
      if (url.pathname==='/etch-icon.png') return new Response(request.method==='HEAD'?null:Uint8Array.from(atob(iconPng),c=>c.charCodeAt(0)),{headers:{'content-type':'image/png','cache-control':'public, max-age=3600'}});
      if (url.pathname==='/etch.webmanifest') return new Response(request.method==='HEAD'?null:JSON.stringify({
        id:'/',name:'ETCH CRM',short_name:'ETCH CRM',start_url:'/',scope:'/',display:'standalone',
        background_color:'#101421',theme_color:'#17182c',lang:'ar',dir:'rtl',
        icons:[{src:'/etch-icon.png',sizes:'512x512',type:'image/png',purpose:'any'}]
      }),{headers:{'content-type':'application/manifest+json','cache-control':'public, max-age=3600'}});
    }
    if (['/demo','/demo/'].includes(url.pathname) && ['GET','HEAD'].includes(request.method)) {
      return new Response(request.method === 'HEAD' ? null : demoPage(), {headers:{...headers,'content-type':'text/html; charset=utf-8'}});
    }
    if (!request.headers.get('oai-authenticated-user-id')) return json({error:'sign_in_required'},401);
    const owner=allowedWrite(request,env);
    const canRead=owner || allowLiveViewer(request,env);
    if (url.pathname==='/api/push/device') {
      if (!owner) return json({error:'denied'},403);
      try { return await pushDevice(request,env); }
      catch { return json({error:'push_request_failed'},400); }
    }
    if (url.pathname==='/api/shared-crm') {
      if (!canRead) return json({error:'demo_only'},403);
      return shared(request,env,owner,url);
    }
    if (!['/','/index.html','/manager','/manager/','/demo','/demo/'].includes(url.pathname)) return json({error:'missing'},404);
    if (request.method!=='GET' && request.method!=='HEAD') return json({error:'method'},405);
    if (!canRead || url.pathname.startsWith('/demo')) {
      return new Response(request.method==='HEAD'?null:demoPage(),{headers:{...headers,'content-type':'text/html; charset=utf-8'}});
    }
    const mode=owner && !url.pathname.startsWith('/manager')?'owner':'viewer';
    const app=appHtml.replace('<html lang="ar" dir="rtl">','<html lang="ar" dir="rtl" data-live-mode="'+mode+'">');
    return new Response(request.method==='HEAD'?null:app,{headers:{...headers,'content-type':'text/html; charset=utf-8'}});
  }
};
